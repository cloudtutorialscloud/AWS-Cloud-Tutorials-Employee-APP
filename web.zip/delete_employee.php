<?php
session_start();
include 'db.php';

// Security check: Only admins can delete
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // 1. Fetch the photo key before deleting the user
    $stmt = $conn->prepare("SELECT photo FROM employees WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if ($user && !empty($user['photo'])) {
        try {
            // 2. Delete the object from S3
            $s3->deleteObject([
                'Bucket' => $bucketName,
                'Key'    => $user['photo']
            ]);
        } catch (Exception $e) {
            // Optionally log that S3 deletion failed
        }
    }

    // 3. Delete the user from MySQL
    $delStmt = $conn->prepare("DELETE FROM employees WHERE id = ?");
    $delStmt->bind_param("i", $id);
    $delStmt->execute();
}

header("Location: admin.php");
exit;
?>
