<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['user'];
$sql = "SELECT * FROM employees WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$emp = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $dept = $_POST['department'];
    $salary = $_POST['salary'];
    $username = $_SESSION['user'];

    // 1. Handle New Photo Upload
    $photoUpdateSQL = "";
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $file_name = time() . "_" . $_FILES['photo']['name'];
        try {
            $s3->putObject([
                'Bucket' => $bucketName,
                'Key'    => "uploads/" . $file_name,
                'SourceFile' => $_FILES['photo']['tmp_name'],
            ]);
            $photoKey = "uploads/" . $file_name;
            // Prepare SQL snippet to update photo column
            $photoUpdateSQL = ", photo='$photoKey'";
        } catch (Exception $e) {
            $error = "S3 Upload Error: " . $e->getMessage();
        }
    }

    // 2. Update Database (Including photo if uploaded)
    $update = "UPDATE employees SET department=?, salary=? $photoUpdateSQL WHERE username=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sss", $dept, $salary, $username);

    if ($stmt->execute()) {
        $success = "Details updated successfully!";
        // Refresh employee data to show new photo immediately
        header("Refresh:2");
    }
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Update Details</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-3">Update Your Details</h2>
    <?php if (!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
    <form method="post" enctype="multipart/form-data">

<div class="mb-3">
        <label class="form-label">Current Profile Photo</label><br>
        <img src="<?php echo $displayUrl; ?>" width="100" class="img-thumbnail mb-2">
        <input type="file" name="photo" class="form-control" accept="image/*">
        <small class="text-muted">Leave empty to keep current photo</small>
    </div>

    <div class="mb-3">
        <label class="form-label">Name</label>
        <input type="text" value="<?php echo $emp['name']; ?>" class="form-control" disabled>
    </div>
    
    <div class="mb-3">
        <label class="form-label">Department</label>
        <input type="text" name="department" value="<?php echo $emp['department']; ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label class="form-label">Salary</label>
        <input type="number" step="0.01" name="salary" value="<?php echo $emp['salary']; ?>" class="form-control">
    </div>

    <button type="submit" class="btn btn-primary w-100">Update Profile</button>

</form>
    <div class="mt-3 text-center">
      <a href="dashboard.php" class="btn btn-secondary">⬅ Go Back</a>
    </div>
  </div>
</div>
</body>
</html>
