<?php
require 'vendor/autoload.php';
use Aws\S3\S3Client;

// 1. RDS MySQL Connection (Private Endpoint)
$host = "database-1.c3equa8ouhix.ap-south-1.rds.amazonaws.com"; // Your RDS Endpoint
$user = "admin";
$pass = "TDITnetworkB2#";
$dbname = "employeedb";

// Connect to RDS
$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// 2. S3 Client Configuration (Mumbai)
$s3 = new S3Client([
    'version' => 'latest',
    'region'  => 'ap-south-1'
]);

$bucketName = "employeeapp-aws";
?>
