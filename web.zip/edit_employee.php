<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}
$id = $_GET['id'];
$sql = "SELECT * FROM employees WHERE id=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$emp = $result->fetch_assoc();
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['name'];
    $dept = $_POST['department'];
    $salary = $_POST['salary'];
    $update = "UPDATE employees SET name=?, department=?, salary=? WHERE id=?";
    $stmt = $conn->prepare($update);
    $stmt->bind_param("sssi", $name, $dept, $salary, $id);
    $stmt->execute();
    header("Location: admin.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Edit Employee</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-3">Edit Employee</h2>
    <form method="post">
      <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" value="<?php echo $emp['name']; ?>" class="form-control"></div>
      <div class="mb-3"><label class="form-label">Department</label><input type="text" name="department" value="<?php echo $emp['department']; ?>" class="form-control"></div>
      <div class="mb-3"><label class="form-label">Salary</label><input type="number" step="0.01" name="salary" value="<?php echo $emp['salary']; ?>" class="form-control"></div>
      <button type="submit" class="btn btn-primary w-100">Update</button>
    </form>
  </div>
</div>
</body>
</html>
