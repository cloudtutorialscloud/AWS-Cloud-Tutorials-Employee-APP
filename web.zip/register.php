<?php
include 'db.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $name = $_POST['name'];
    $emp_id = $_POST['emp_id'];
    $dept = $_POST['department'];
    $salary = $_POST['salary'];
    $username = $_POST['username'];
    $password = md5($_POST['password']);
    
    // S3 Photo Upload Logic
    $photoKey = "";
    if (isset($_FILES['photo']) && $_FILES['photo']['error'] == 0) {
        $file_name = time() . "_" . $_FILES['photo']['name'];
        $temp_file_path = $_FILES['photo']['tmp_name'];

        try {
            $result = $s3->putObject([
                'Bucket' => $bucketName,
                'Key'    => "uploads/" . $file_name,
                'SourceFile' => $temp_file_path,
            ]);
            $photoKey = "uploads/" . $file_name;
        } catch (Exception $e) {
            echo "S3 Upload Error: " . $e->getMessage();
        }
    }

    $sql = "INSERT INTO employees (emp_id, name, department, salary, username, password, photo) VALUES (?,?,?,?,?,?,?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $emp_id, $name, $dept, $salary, $username, $password, $photoKey);

    // ADD THIS EXECUTION LOGIC:
    if ($stmt->execute()) {
        echo "<div class='alert alert-success mt-3'>Registration successful! <a href='index.php'>Login here</a></div>";
    } else {
        // This will display the exact error if the database rejects the save
        echo "<div class='alert alert-danger mt-3'>Database Error: " . $stmt->error . "</div>";
    }
    $stmt->close();
    // ... rest of execute logic ...
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Employee Registration</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-3">Employee Registration</h2>
    <form method="post" enctype="multipart/form-data">
      <div class="mb-3">
    <label class="form-label">Profile Photo</label>
    <input type="file" name="photo" class="form-control" accept="image/*">
  </div>
      <div class="mb-3"><label class="form-label">Employee ID</label><input type="text" name="emp_id" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Name</label><input type="text" name="name" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Department</label><input type="text" name="department" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Salary</label><input type="number" step="0.01" name="salary" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Username</label><input type="text" name="username" class="form-control" required></div>
      <div class="mb-3"><label class="form-label">Password</label><input type="password" name="password" class="form-control" required></div>
      <button type="submit" class="btn btn-success w-100">Register</button>
    </form>
  </div>
</div>
</body>
</html>
