<?php
session_start();
include 'db.php';
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$username = $_SESSION['user'];
$sql = "SELECT * FROM employees WHERE username=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$emp = $result->fetch_assoc();

$displayUrl = "https://cdn-icons-png.flaticon.com/512/149/149071.png"; // Default Avatar

if (!empty($emp['photo'])) {
    try {
        $cmd = $s3->getCommand('GetObject', [
            'Bucket' => $bucketName,
            'Key'    => $emp['photo']
        ]);
        $request = $s3->createPresignedRequest($cmd, '+20 minutes');
        $displayUrl = (string)$request->getUri();
    } catch (Exception $e) {
        // Fallback if image doesn't exist in S3
    }
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Employee Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-3 text-center">Welcome, <?php echo $emp['name']; ?></h2>
    <h5>Your Details</h5>
    <table class="table table-bordered">
      <tr><th>Employee ID</th><td><?php echo $emp['emp_id']; ?></td></tr>
      <tr><th>Name</th><td><?php echo $emp['name']; ?></td></tr>
      <tr><th>Department</th><td><?php echo $emp['department']; ?></td></tr>
      <tr><th>Salary</th><td><?php echo $emp['salary']; ?></td></tr>
      <tr><th>Username</th><td><?php echo $emp['username']; ?></td></tr>
      <tr><th>Profile Photo</th><td><img src="<?php echo $displayUrl; ?>" width="100"></td></tr>
 </table>
    <div class="mt-3 text-center">
      <a href="details.php" class="btn btn-info">Update Details</a>
      <a href="logout.php" class="btn btn-danger">Logout</a>
    </div>
  </div>
</div>
</body>
</html>
