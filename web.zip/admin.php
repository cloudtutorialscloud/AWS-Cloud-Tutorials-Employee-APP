<?php
session_start();
include 'db.php';
if (!isset($_SESSION['admin'])) {
    header("Location: index.php");
    exit;
}
$result = $conn->query("SELECT * FROM employees");
?>
<!DOCTYPE html>
<html>
<head>
  <title>Admin Dashboard</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
  <div class="card shadow p-4">
    <h2 class="mb-3">Admin Dashboard</h2>
    <table class="table table-striped table-bordered">
      <thead class="table-dark">
        <tr><th>ID</th><th>Name</th><th>Department</th><th>Salary</th><th>Username</th><th>Actions</th></tr>
      </thead>
      <tbody>
      

<?php 
while ($row = $result->fetch_assoc()) { 
    // Default avatar if no photo exists
    $adminDisplayUrl = "https://cdn-icons-png.flaticon.com/512/149/149071.png";

    if (!empty($row['photo'])) {
        try {
            $cmd = $s3->getCommand('GetObject', [
                'Bucket' => $bucketName,
                'Key'    => $row['photo']
            ]);
            $request = $s3->createPresignedRequest($cmd, '+20 minutes');
            $adminDisplayUrl = (string)$request->getUri();
        } catch (Exception $e) {
            // Log error if needed
        }
    }
?>
<tr>
    <td><img src="<?php echo $adminDisplayUrl; ?>" width="50" class="rounded-circle"></td>
    <td><?php echo $row['emp_id']; ?></td>
    <td><?php echo $row['name']; ?></td>
    <td><?php echo $row['department']; ?></td>
    <td><?php echo $row['salary']; ?></td>
    <td><?php echo $row['username']; ?></td>
    <td>
        <a href="edit_employee.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
        <a href="delete_employee.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure? This will also delete the S3 photo.');">Delete</a>
    </td>
</tr>
<?php } ?>


      </tbody>
    </table>
    <div class="mt-3 text-center">
      <a href="logout.php" class="btn btn-secondary">Logout</a>
    </div>
  </div>
</div>
</body>
</html>
